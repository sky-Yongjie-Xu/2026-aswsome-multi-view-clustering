clear all; clc; close all;
addpath(genpath('utils')); 

%% Initialize
load(['100leaves_0.5_incomplete.mat']); % X{v}, W{v}, truelabel

% variable initialize
num_views = length(Xo); %View
[~, n] = size(X{1});% Sample

tic;
for v = 1:num_views
    dv(v) = size(X{v}, 1); % Dimensions
    X{v} = X{v}./repmat(sqrt(sum(X{v}.^2,1)),size(X{v},1),1);
    X{v}(isnan(X{v})) = 0;
end

% Parameter settings
lambda1 = 1; % E2,E_H [1, 20, 30, 40, 50]
lambda2 = 40; % E1    [1, 20, 30, 40, 50]
mu = 1e-3; 
rho = 1.3; 
k = 20; %10, 20
epsilon = 1e-7;
tol = 1e-3;
mu_max = 1e10; 
max_iter =30; 
num_clusters = length(unique(truelabel)); 
num_runs =10; 
results_all = zeros(num_runs, 8);
for v = 1:num_views
    dv(v) = size(X{v}, 1); % Dimensions
    X{v} = X{v}./repmat(sqrt(sum(X{v}.^2,1)),size(X{v},1),1);
    X{v}(isnan(X{v})) = 0;
end
P = cell(1, num_views);
Xc = cell(1, num_views);
E1 = cell(1, num_views);
E2 = cell(1, num_views);
H = zeros(k, n);
EH = zeros(k, n);
Y4 = zeros(k, n); 

for v = 1:num_views
    Xc{v} = X{v};
    E1{v} = zeros(dv(v), n);
    E2{v} = zeros(dv(v), n);
    Y1{v} = zeros(dv(v), n);
    Y2{v} = zeros(dv(v), n);
    Y3{v} = zeros(dv(v), n);
end
for v=1:num_views+1
     Zv{v} = zeros(n, n);
     Jv{v} = zeros(n, n);
     Yv{v} = zeros(n, n);
end
J_tensor = cat(3, Jv{:,:});
iter = 0;
Isconverg = 0;
time1 = toc;

%% Main loop
obj_vals = [];
residuals_history = struct('Z_J', [], 'Xc_PHE1', [], 'XW_XcW', [], 'Xc_XcZ_E2', [], 'H_HZ_EH', []);
obj_changes = [];
tic;

while(Isconverg == 0) 
    %% Update P^{v}
    for v = 1:num_views
        Q = (Xc{v} - E1{v} + Y1{v}/mu)';
        [U1, ~, V1] = svd(H * Q, 'econ');
        P{v} = V1 * U1';
    end  

    %% Update Xc^{v}
    for v = 1:num_views
        A1 = P{v} * H + E1{v} - Y1{v}/mu;
        A2 = X{v} * W{v} + Y2{v}/mu;
        A3 = E2{v} - Y3{v}/mu;
        WvT = W{v} * W{v}';
        I_minus_Zv = eye(n) - Zv{v};
        denom = eye(n) + WvT + I_minus_Zv * I_minus_Zv'; %+ (1e-3)*eye(n)
        Xc{v} = (A1 + A2 * W{v}' + A3 * I_minus_Zv' ) / denom;

    end

    %% Update H
    A = zeros(k, k);
    B = mu * (eye(n) - Zv{num_views+1} -  Zv{num_views+1}' + Zv{num_views+1} * Zv{num_views+1}')+eye(n)*(1e-5);
    C = zeros(k, n);
    for v = 1:num_views
        A = A + mu * P{v}' * P{v};
    end
    A = A + epsilon * eye(k);
    for v = 1:num_views
        C = C + mu * P{v}' * (Xc{v} - E1{v} + Y1{v}/mu);
    end
    C = C + mu * (EH - Y4/mu) * (eye(n) - Zv{num_views+1}');
    H = lyap(A, B, C);
    
    %% Update Z^{(v)}
    for v = 1:num_views
       S_Z = Xc{v}' * (Xc{v} - E2{v} + Y3{v}/mu)+Jv{v}-Yv{v}/mu;
       Zv{v} = (Xc{v}' * Xc{v} + eye(n)) \ S_Z;
    end

    %% Update Z (Z_tensor(:, :, V+1))
    S_Z1 = EH - Y4/mu;
    S_Z2 = Jv{ num_views+1} - Yv{num_views+1}/mu;
    Zv{num_views+1} = (H' * H + eye(n)) \ (H' * (H - S_Z1) + S_Z2);

    %% Update E1^{v}
    for v = 1:num_views
        S_E1 = Xc{v} - P{v} * H - Y1{v}/mu;
        Q = computeHSICKernel(E1, v, num_views);
        E1{v} = S_E1 / (eye(n) + (2 * lambda2 / (mu * (num_views - 1)^2)) * Q);
    end

    %% Update E2^{v}
    for v = 1:num_views
        S_E2 = Xc{v}*(eye(n)-Zv{v}) + Y3{v}/mu;
        E2{v} = solveL21(S_E2, lambda1/mu);
    end

    %% Update EH
    S_EH = H*(eye(n)-Zv{num_views+1}) + Y4/mu;
    EH = solveL21(S_EH, lambda1/mu);
    
    %% Update J_tensor using T-SVD
    Z_tensor = cat(3, Zv{:,:});
    Y_tensor = cat(3, Yv{:,:});
    J_tensor = logSchatten_Shrink(Z_tensor + Y_tensor/mu, J_tensor, 1/mu, 3, 1); 

    %% Update Lagrange multipliers
    Y_tensor = Y_tensor + mu * (Z_tensor - J_tensor);
    for v = 1:num_views
        Y1{v} = Y1{v} + mu * (Xc{v} - P{v} * H - E1{v});
        Y2{v} = Y2{v} + mu * (X{v} * W{v} - Xc{v} * W{v});
        Y3{v} = Y3{v} + mu * (Xc{v} - Xc{v} * Zv{v} - E2{v});
        Jv{v} = J_tensor(:,:,v);
        Yv{v} = Y_tensor(:,:,v);
    end
    Jv{num_views+1} = J_tensor(:,:,num_views+1);
    Yv{num_views+1} = Y_tensor(:,:,num_views+1);
    Y4 = Y4 + mu * H*(eye(n) -  Zv{num_views+1}) - EH;

   
    %% Coverge condition
    Isconverg = 0;

    if (iter>=max_iter)
        Isconverg  = 1;
    end
    
    iter = iter+1;
    
    %% Update mu
    mu = min(mu * rho, mu_max);
   
end
time2 = toc;

%% Clustering Measure
Zsum=zeros(n,n);
for v = 1:num_views
   Z1 = abs(Zv{v}');
   Zsum = Zsum+abs(Zv{v})+Z1;
end
S = (abs(Zv{num_views+1})+abs(Zv{num_views+1}')+Zsum) / (num_views+1);
tic;
kerNS = SpectralClustering(S, num_clusters);
MAXiter = 1000; % Maximum number of iterations for k-means
REPlic = 20; % Number of replications for k-means

for run = 1:num_runs
    fprintf('Run %d/%d\n', run, num_runs);   
    pred_labels = kmeans(kerNS, num_clusters, 'maxiter', MAXiter, 'replicates', REPlic, 'EmptyAction', 'singleton');
    pred_labels = round(pred_labels(:));
    result = ClusteringMeasure(truelabel, pred_labels);
    results_all(run, :) = result(:)';
    fprintf('Run %d：ACC: %.4f, NMI: %.4f, Purity: %.4f\n',run, result(1), result(2), result(5));
end
time3 = toc;

%% Compute average results
runtime = time1 + time2/max_iter+ time3/ num_runs;
mean_results = mean(results_all, 1);
std_results = std(results_all, 0, 1); 

fprintf('\nAverage Results over %d runs:\n', num_runs);
fprintf('Mean ACC: %.4f ± %.4f\n', mean_results(1), std_results(1));
fprintf('Mean NMI: %.4f ± %.4f\n', mean_results(2), std_results(2));
fprintf('Mean Purity: %.4f ± %.4f\n', mean_results(5), std_results(5));

