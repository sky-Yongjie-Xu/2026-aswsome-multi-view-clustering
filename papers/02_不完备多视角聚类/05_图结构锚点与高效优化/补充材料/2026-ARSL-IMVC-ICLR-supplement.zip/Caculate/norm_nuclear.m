% Compute the nuclear norm of matrix X
% Input：X - matrix
% Output：n - nuclear norm
function n = norm_nuclear(X)
    [~, S, ~] = svd(X, 'econ'); 
    n = sum(diag(S)); 
end