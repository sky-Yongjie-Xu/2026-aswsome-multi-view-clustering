% Calculate the HSIC kernel matrix Q of the v-th view to update E1{v}
% Input：E, v, num_views 
% Output：Q - kernel matrix
function Q = computeHSICKernel(E, v, num_views)
    n = size(E{1}, 2); 
    Q = zeros(n, n); 
    H = eye(n) - (1/n) * ones(n, n);
    for w = 1:num_views
        if w ~= v
            % Inner product kernel
            K_w = E{w}' * E{w};
            K_w_centered = H * K_w * H;
            Q = Q + K_w_centered;
        end
    end
    
    Q(isnan(Q) | isinf(Q)) = 0;
end