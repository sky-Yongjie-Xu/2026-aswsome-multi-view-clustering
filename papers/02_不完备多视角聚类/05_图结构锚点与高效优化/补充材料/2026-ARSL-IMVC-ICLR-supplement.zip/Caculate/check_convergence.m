% check_convergence.m
% Inputs:
%   Z_tensor, J_tensor
%   X, Xc, W, E1, E2, EH
%   num_views
%   tol
% Outputs:
%   is_converged
%   residuals
%   obj_change

function [is_converged, residuals, obj_change] = check_convergence(Z_tensor, J_tensor, P, X, Xc, W, E1, E2, EH, H, num_views, tol, obj_vals)

    residuals = struct();
    
    % Z - J 
    residuals.Z_J = zeros(1, num_views+1);
    for k = 1:(num_views+1)
        residuals.Z_J(k) = norm(Z_tensor(:, :, k) - J_tensor(:, :, k), 'fro');
    end
    
    % Xc - P*H - E1 
    residuals.Xc_PHE1 = zeros(1, num_views);
    for v = 1:num_views
        residuals.Xc_PHE1(v) = norm(Xc{v} - P{v} * H - E1{v}, 'fro');
    end
    
    % X*W - Xc*W 
    residuals.XW_XcW = zeros(1, num_views);
    for v = 1:num_views
        residuals.XW_XcW(v) = norm((X{v} .* (~isnan(X{v}))) * diag(W{v}) - Xc{v} * diag(W{v}), 'fro');
    end
    
    % Xc - Xc*Z - E2
    residuals.Xc_XcZ_E2 = zeros(1, num_views);
    for v = 1:num_views
        residuals.Xc_XcZ_E2(v) = norm(Xc{v} - Xc{v} * Z_tensor(:, :, v) - E2{v}, 'fro');
    end
    
    % H - H*Z - EH
    residuals.H_HZ_EH = norm(H - H * Z_tensor(:, :, num_views+1) - EH, 'fro');
    
    % obj_change
    if length(obj_vals) >= 2
        obj_change = abs(obj_vals(end) - obj_vals(end-1));
    else
        obj_change = Inf;
    end
    
    % 判断是否收敛
    max_residual = max([max(residuals.Z_J), max(residuals.Xc_PHE1), max(residuals.XW_XcW), max(residuals.Xc_XcZ_E2), residuals.H_HZ_EH]);
    is_converged = (max_residual < tol) && (obj_change < tol);
    
    
%{
    disp('当前迭代的收敛信息:');
    disp(['Z - J 最大残差: ' num2str(max(residuals.Z_J))]);
    disp(['Xc - P*H - E1 最大残差: ' num2str(max(residuals.Xc_PHE1))]);
    disp(['X*W - Xc*W 最大残差: ' num2str(max(residuals.XW_XcW))]);
    disp(['Xc - Xc*Z - E2 最大残差: ' num2str(max(residuals.Xc_XcZ_E2))]);
    disp(['H - H*Z - EH 残差: ' num2str(residuals.H_HZ_EH)]);
    disp(['目标函数值变化: ' num2str(obj_change)]);
end
%}

