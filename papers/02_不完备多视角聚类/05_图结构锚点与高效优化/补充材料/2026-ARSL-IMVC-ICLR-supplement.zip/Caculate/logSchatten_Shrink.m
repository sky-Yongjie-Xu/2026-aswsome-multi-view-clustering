function [X] = logSchatten_Shrink(X,G, lambda, mode,p)

sX = size(X);

if mode == 3
    n3 = sX(1);
    m = min(sX(2), sX(3));
else
    n3 = sX(3);
    m = min(sX(1), sX(2));
end

if p==1
    if mode == 1
       Y=X2Yi(X,3);
    elseif  mode == 3
       Y = shiftdim(X, 1);
    else
       Y = X;
    end
    Yhat = fft(Y,[],3);

    if mod(n3,2) == 0
       endValue = n3/2;
       for i = 1:endValue
          [uhat,shat,vhat] = svd(full(Yhat(:,:,i)),'econ');
          for j = 1:m
             shat(j,j) = update_log(shat(j,j),lambda);
          end
          Yhat(:,:,i) = uhat*shat*vhat';
          if i > 1 
             Yhat(:,:,n3-i+2) = conj(uhat)*shat*conj(vhat)';
          end
       end
       [uhat,shat,vhat] = svd(full(Yhat(:,:,endValue+1)),'econ');
       for j = 1:m
           shat(j,j) = update_log(shat(j,j),lambda);
       end
       Yhat(:,:,endValue+1) = uhat*shat*vhat';
    else
       endValue = (n3+1)/2;
       for i = 1:endValue
          [uhat,shat,vhat] = svd(full(Yhat(:,:,i)),'econ');
          for j = 1:m
             shat(j,j) = update_log(shat(j,j),lambda);
          end
          Yhat(:,:,i) = uhat*shat*vhat';
          if i > 1 
             Yhat(:,:,n3-i+2) = conj(uhat)*shat*conj(vhat)';
          end
       end
    end
else
    if mode == 1
       Y=X2Yi(X,3);
       Y1 = X2Yi(G,3);
    elseif  mode == 3
       Y = shiftdim(X, 1);
       Y1 = shiftdim(G,1);
    else
       Y = X;
       Y1 = G;
    end

   Yhat = fft(Y,[],3);
   Y1hat = fft(Y1,[],3);
    if mod(n3,2) == 0
       endValue = n3/2;
       for i = 1:endValue
          [uhat,shat,vhat] = svd(full(Yhat(:,:,i)),'econ');
          shat1 = svd(full(Y1hat(:,:,i)),'econ');
          for j = 1:m
              tau = (lambda*p*shat1(j)^(p-1))/(1+shat1(j)^p);
              shat(j,j) = max(shat(j,j) - tau,0);
          end
          Yhat(:,:,i) = uhat*shat*vhat';
          if i > 1 
             Yhat(:,:,n3-i+2) = conj(uhat)*shat*conj(vhat)';
          end
       end
       [uhat,shat,vhat] = svd(full(Yhat(:,:,endValue+1)),'econ');
       shat1 = svd(full(Y1hat(:,:,endValue)),'econ');
       for j = 1:m
           tau = (lambda*p*shat1(j)^(p-1))/(1+shat1(j)^p);
           shat(j,j) = max(shat(j,j) - tau,0);
       end
       Yhat(:,:,endValue+1) = uhat*shat*vhat';
    else
       endValue = (n3+1)/2;
       for i = 1:endValue
          [uhat,shat,vhat] = svd(full(Yhat(:,:,i)),'econ');
          shat1 = svd(full(Y1hat(:,:,i)),'econ');
          for j = 1:m
             tau = (lambda*p*shat1(j)^(p-1))/(1+shat1(j)^p);
             shat(j,j) = max(shat(j,j) - tau,0);
          end
          Yhat(:,:,i) = uhat*shat*vhat';
          if i > 1 
             Yhat(:,:,n3-i+2) = conj(uhat)*shat*conj(vhat)';
          end
       end
    end 
end       
         
         
           
     
%% Raw IFFT
Y = ifft(Yhat,[],3);
%% New IFFT
% for c=1:n2
%     Y(:,c,:)=ifft(Yhat(:,c,:));
% end
if mode == 1
    X = Yi2X(Y,3);
elseif mode == 3
    X = shiftdim(Y, 2);
else
    X = Y;
end
