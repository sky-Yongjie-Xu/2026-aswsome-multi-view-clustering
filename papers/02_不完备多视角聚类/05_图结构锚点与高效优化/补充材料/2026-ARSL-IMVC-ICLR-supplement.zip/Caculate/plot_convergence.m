function plot_convergence(obj_vals, residuals_history)
% plot_convergence.m
% Inputs: obj_vals、residuals_history

    %Objective function value curve
    figure;
    subplot(2, 1, 1);
    plot(1:length(obj_vals), obj_vals, 'b-', 'LineWidth', 2);
    xlabel('Iteration');
    ylabel('Objective Function Value');
    title('Convergence of Objective Function');
    grid on;

    % residuals_history
    subplot(2, 1, 2);
    plot(1:length(residuals_history.Z_J), residuals_history.Z_J, 'r-', 'LineWidth', 2, 'DisplayName', 'Z - J');
    hold on;
    plot(1:length(residuals_history.Xc_PHE1), residuals_history.Xc_PHE1, 'g-', 'LineWidth', 2, 'DisplayName', 'Xc - P*H - E1');
    plot(1:length(residuals_history.XW_XcW), residuals_history.XW_XcW, 'b-', 'LineWidth', 2, 'DisplayName', 'X*W - Xc*W');
    plot(1:length(residuals_history.Xc_XcZ_E2), residuals_history.Xc_XcZ_E2, 'm-', 'LineWidth', 2, 'DisplayName', 'Xc - Xc*Z - E2');
    plot(1:length(residuals_history.H_HZ_EH), residuals_history.H_HZ_EH, 'k-', 'LineWidth', 2, 'DisplayName', 'H - H*Z - EH');
    xlabel('Iteration');
    ylabel('Residual');
    title('Convergence of Residuals');
    legend('show');
    grid on;
end