function result = ClusteringMeasure(truelabel, pred_labels)

% 确保输入为数值向量

if size(truelabel, 2) ~= 1
   truelabel = truelabel';
end

% 确保输入为列向量
n = length(truelabel);


if size(pred_labels, 2) ~= 1
    pred_labels = pred_labels';
end


uY = unique(truelabel);
nclass = length(uY);
Y0 = zeros(n,1);
if nclass ~= max(truelabel)
    for i = 1:nclass
        Y0(find(truelabel == uY(i))) = i;
    end
    truelabel = Y0;
end

uY = unique(pred_labels);
nclass = length(uY);
predY0 = zeros(n,1);
if nclass ~= max(pred_labels)
    for i = 1:nclass
        predY0(find(pred_labels == uY(i))) = i;
    end
    pred_labels = predY0;
end

Lidx = unique(truelabel); classnum = length(Lidx);
predLidx = unique(pred_labels); pred_classnum = length(predLidx);

% purity
correnum = 0;
for ci = 1:pred_classnum
    incluster = truelabel(find(pred_labels == predLidx(ci)));
    inclunub = hist(incluster, 1:max(incluster)); if isempty(inclunub) inclunub=0;end;
    correnum = correnum + max(inclunub);
end
Purity = correnum/length(pred_labels);

res = bestMap(truelabel, pred_labels);
% accuracy
ACC = length(find(truelabel == res))/length(truelabel);
% NMI
MIhat = MutualInfo(truelabel,res);

[Fscore Precision Recall] = compute_f(truelabel, pred_labels); 
[nmi Entropy] = compute_nmi(truelabel, pred_labels);
AR = RandIndex(truelabel, pred_labels);

result = [ACC nmi AR Fscore Purity Precision Recall Entropy];
end

%% 以下为原有的子函数，保持不变
function [nmi clust_ent] = compute_nmi(T, H)
    N = length(T);
    classes = unique(T);
    clusters = unique(H);
    num_class = length(classes);
    num_clust = length(clusters);

    for j=1:num_class
        index_class = (T(:)==classes(j));
        D(j) = sum(index_class);
    end      

    mi = 0;
    A = zeros(num_clust, num_class);
    avgent = 0;
    for i=1:num_clust
        index_clust = (H(:)==clusters(i));
        B(i) = sum(index_clust);
        for j=1:num_class
            index_class = (T(:)==classes(j));
            A(i,j) = sum(index_class.*index_clust);
            if (A(i,j) ~= 0)
                miarr(i,j) = A(i,j)/N * log2(N*A(i,j)/(B(i)*D(j)));
                avgent = avgent - (B(i)/N) * (A(i,j)/B(i)) * log2(A(i,j)/B(i));
            else
                miarr(i,j) = 0;
            end
            mi = mi + miarr(i,j);
        end        
    end
    
    class_ent = 0;
    for i=1:num_class
        class_ent = class_ent + D(i)/N * log2(N/D(i));
    end
    
    clust_ent = 0;
    for i=1:num_clust
        clust_ent = clust_ent + B(i)/N * log2(N/B(i));
    end
        
    nmi = 2*mi / (clust_ent + class_ent);
end

function [AR,RI,MI,HI]=RandIndex(c1,c2)
if nargin < 2 | min(size(c1)) > 1 | min(size(c2)) > 1
   error('RandIndex: Requires two vector arguments')
   return
end

C=Contingency(c1,c2);

n=sum(sum(C));
nis=sum(sum(C,2).^2);
njs=sum(sum(C,1).^2);

t1=nchoosek(n,2);
t2=sum(sum(C.^2));
t3=.5*(nis+njs);

nc=(n*(n^2+1)-(n+1)*nis-(n+1)*njs+2*(nis*njs)/n)/(2*(n-1));

A=t1+t2-t3;
D=  -t2+t3;

if t1==nc
   AR=0;
else
   AR=(A-nc)/(t1-nc);
end

RI=A/t1;
MI=D/t1;
HI=(A-D)/t1;
end

function [f,p,r] = compute_f(T,H)
  if length(T) ~= length(H),
    size(T)
    size(H)
  end;
  
  N = length(T);
  numT = 0;
  numH = 0;
  numI = 0;
  for n=1:N
    Tn = (T(n+1:end))==T(n);
    Hn = (H(n+1:end))==H(n);
    numT = numT + sum(Tn);
    numH = numH + sum(Hn);
    numI = numI + sum(Tn .* Hn);
  end
  p = 1;
  r = 1;
  f = 1;
  if numH > 0
    p = numI / numH;
  end
  if numT > 0
    r = numI / numT;
  end
  if (p+r) == 0
    f = 0;
  else
    f = 2 * p * r / (p + r);
  end
end

function Cont=Contingency(Mem1,Mem2)
if nargin < 2 | min(size(Mem1)) > 1 | min(size(Mem2)) > 1
   error('Contingency: Requires two vector arguments')
   return
end

Cont=zeros(max(Mem1),max(Mem2));

for i = 1:length(Mem1)
   Cont(Mem1(i),Mem2(i))=Cont(Mem1(i),Mem2(i))+1;
end
end

function [newL2, c] = bestMap(L1,L2)
L1 = L1(:);
L2 = L2(:);
if size(L1) ~= size(L2)
    error('size(L1) must == size(L2)');
end
L1 = L1 - min(L1) + 1;
L2 = L2 - min(L2) + 1;

nClass = max(max(L1), max(L2));
G = zeros(nClass);
for i=1:nClass
    for j=1:nClass
        G(i,j) = length(find(L1 == i & L2 == j));
    end
end

[c,t] = hungarian(-G);
newL2 = zeros(nClass,1);
for i=1:nClass
    newL2(L2 == i) = c(i);
end
end

function MIhat = MutualInfo(L1,L2)
L1 = L1(:);
L2 = L2(:);
if size(L1) ~= size(L2)
    error('size(L1) must == size(L2)');
end
L1 = L1 - min(L1) + 1;
L2 = L2 - min(L2) + 1;

nClass = max(max(L1), max(L2));
G = zeros(nClass);
for i=1:nClass
    for j=1:nClass
        G(i,j) = length(find(L1 == i & L2 == j))+eps;
    end
end
sumG = sum(G(:));

P1 = sum(G,2);  P1 = P1/sumG;
P2 = sum(G,1);  P2 = P2/sumG;
H1 = sum(-P1.*log2(P1));
H2 = sum(-P2.*log2(P2));
P12 = G/sumG;
PPP = P12./repmat(P2,nClass,1)./repmat(P1,1,nClass);
PPP(abs(PPP) < 1e-12) = 1;
MI = sum(P12(:) .* log2(PPP(:)));
MIhat = MI / max(H1,H2);
MIhat = real(MIhat);
end

function [C,T]=hungarian(A)
[m,n]=size(A);

if (m~=n)
    error('HUNGARIAN: Cost matrix must be square!');
end

orig=A;

A=hminired(A);

[A,C,U]=hminiass(A);

while (U(n+1))
    LR=zeros(1,n);
    LC=zeros(1,n);
    CH=zeros(1,n);
    RH=[zeros(1,n) -1];
    
    SLC=[];
    
    r=U(n+1);
    LR(r)=-1;
    SLR=r;
    
    while (1)
        if (A(r,n+1)~=0)
            l=-A(r,n+1);
            
            if (A(r,l)~=0 & RH(r)==0)
                RH(r)=RH(n+1);
                RH(n+1)=r;
                CH(r)=-A(r,l);
            end
        else
            if (RH(n+1)<=0)
                [A,CH,RH]=hmreduce(A,CH,RH,LC,LR,SLC,SLR);
            end
            
            r=RH(n+1);
            l=CH(r);
            CH(r)=-A(r,l);
            if (A(r,l)==0)
                RH(n+1)=RH(r);
                RH(r)=0;
            end
        end
        
        while (LC(l)~=0)
            if (RH(r)==0)
                if (RH(n+1)<=0)
                    [A,CH,RH]=hmreduce(A,CH,RH,LC,LR,SLC,SLR);
                end
                r=RH(n+1);
            end
            
            l=CH(r);
            CH(r)=-A(r,l);
            if(A(r,l)==0)
                RH(n+1)=RH(r);
                RH(r)=0;
            end
        end
        
        if (C(l)==0)
            [A,C,U]=hmflip(A,C,LC,LR,U,l,r);
            break;
        else
            LC(l)=r;
            SLC=[SLC l];
            r=C(l);
            LR(r)=l;
            SLR=[SLR r];
        end
    end
end

T=sum(orig(logical(sparse(C,1:size(orig,2),1))));
end

function A=hminired(A)
[m,n]=size(A);

colMin=min(A);
A=A-colMin(ones(n,1),:);

rowMin=min(A')';
A=A-rowMin(:,ones(1,n));

[i,j]=find(A==0);

A(1,n+1)=0;
for k=1:n
    cols=j(k==i)';
    A(k,[n+1 cols])=[-cols 0];
end
end

function [A,C,U]=hminiass(A)
[n,np1]=size(A);

C=zeros(1,n);
U=zeros(1,n+1);

LZ=zeros(1,n);
NZ=zeros(1,n);

for i=1:n
    lj=n+1;
    j=-A(i,lj);
    
    while (C(j)~=0)
        lj=j;
        j=-A(i,lj);
        if (j==0)
            break;
        end
    end

    if (j~=0)
        C(j)=i;
        A(i,lj)=A(i,j);
        NZ(i)=-A(i,j);
        LZ(i)=lj;
        A(i,j)=0;
    else
        lj=n+1;
        j=-A(i,lj);
        
        while (j~=0)
            r=C(j);
            lm=LZ(r);
            m=NZ(r);
            
            while (m~=0)
                if (C(m)==0)
                    break;
                end
                lm=m;
                m=-A(r,lm);
            end
            
            if (m==0)
                lj=j;
                j=-A(i,lj);
            else
                A(r,lm)=-j;
                A(r,j)=A(r,m);
                NZ(r)=-A(r,m);
                LZ(r)=j;
                A(r,m)=0;
                C(m)=r;
                A(i,lj)=A(i,j);
                NZ(i)=-A(i,j);
                LZ(i)=lj;
                A(i,j)=0;
                C(j)=i;
                break;
            end
        end
    end
end

r=zeros(1,n);
rows=C(C~=0);
r(rows)=rows;
empty=find(r==0);

U=zeros(1,n+1);
U([n+1 empty])=[empty 0];
end

function [A,C,U]=hmflip(A,C,LC,LR,U,l,r)
n=size(A,1);

while (1)
    C(l)=r;
    m=find(A(r,:)==-l);
    A(r,m)=A(r,l);
    A(r,l)=0;
    
    if (LR(r)<0)
        U(n+1)=U(r);
        U(r)=0;
        return;
    else
        l=LR(r);
        A(r,l)=A(r,n+1);
        A(r,n+1)=-l;
        r=LC(l);
    end
end
end

function [A,CH,RH]=hmreduce(A,CH,RH,LC,LR,SLC,SLR)
n=size(A,1);

coveredRows=LR==0;
coveredCols=LC~=0;

r=find(~coveredRows);
c=find(~coveredCols);

m=min(min(A(r,c)));

A(r,c)=A(r,c)-m;

for j=c
    for i=SLR
        if (A(i,j)==0)
            if (RH(i)==0)
                RH(i)=RH(n+1);
                RH(n+1)=i;
                CH(i)=j;
            end
            row=A(i,:);
            colsInList=-row(row<0);
            if (length(colsInList)==0)
                l=n+1;
            else
                l=colsInList(row(colsInList)==0);
            end
            A(i,l)=-j;
        end
    end
end

r=find(coveredRows);
c=find(coveredCols);

[i,j]=find(A(r,c)<=0);

i=r(i);
j=c(j);

for k=1:length(i)
    lj=find(A(i(k),:)==-j(k));
    A(i(k),lj)=A(i(k),j(k));
    A(i(k),j(k))=0;
end

A(r,c)=A(r,c)+m;
end