% Caculate E = arg min_E (1/2) ||E - S||_F^2 + lambda ||E||_{2,1}
% Input：S, lambda - parameter
% Output：E 
function E = solveL21(S, lambda)
    [d, n] = size(S);
    E = zeros(d, n);
    for j = 1:n
        norm_col = norm(S(:,j));
        if norm_col > lambda
            E(:,j) = (1 - lambda / norm_col) * S(:,j);
        else
            E(:,j) = 0;
        end
    end
end