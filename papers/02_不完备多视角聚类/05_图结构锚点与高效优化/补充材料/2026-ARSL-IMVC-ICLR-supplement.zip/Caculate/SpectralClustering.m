%--------------------------------------------------------------------------
% This function takes an adjacency matrix of a graph and computes the 
% clustering of the nodes using the spectral clustering algorithm of 
% Ng, Jordan and Weiss.
% CMat: NxN adjacency matrix
% n: number of groups for clustering
% groups: N-dimensional vector containing the memberships of the N points 
% to the n groups obtained by spectral clustering
%--------------------------------------------------------------------------
% Copyright @ Ehsan Elhamifar, 2012
%--------------------------------------------------------------------------



function kerNS = SpectralClustering(CKSym,n)


warning off;
N = size(CKSym,1);
MAXiter = 1000; % Maximum number of iterations for KMeans 
REPlic = 20; % Number of replications for KMeans

% Normalized spectral clustering according to Ng & Jordan & Weiss
% using Normalized Symmetric Laplacian L = I - D^{-1/2} W D^{-1/2}
DN = diag( 1./sqrt(sum(CKSym)+eps) );
LapN = speye(N) - DN * CKSym * DN;
[uN,sN,vN] = svd(LapN);
kerN = vN(:,N-n+1:N);

for i = 1:N
    kerNS(i,:) = kerN(i,:) ./ norm(kerN(i,:)+eps);
end
groups = kmeans(kerNS,n,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');




%--------------------------------------------------------------------------
% This function takes an adjacency matrix of a graph and computes the 
% clustering of the nodes using the spectral clustering algorithm of 
% Ng, Jordan and Weiss.
% CMat: NxN adjacency matrix
% n: number of groups for clustering
% groups: N-dimensional vector containing the memberships of the N points 
% to the n groups obtained by spectral clustering
%--------------------------------------------------------------------------
% Copyright @ Ehsan Elhamifar, 2012
%--------------------------------------------------------------------------


%{
function groups = SpectralClustering(CKSym, n)
warning off;
N = size(CKSym, 1);
MAXiter = 1000; % Maximum number of iterations for KMeans 
REPlic = 20; % Number of replications for KMeans
% Normalized spectral clustering according to Ng & Jordan & Weiss
% using Normalized Symmetric Laplacian L = I - D^{-1/2} W D^{-1/2}
DN = diag(1 ./ sqrt(sum(CKSym) + eps));
LapN = speye(N) - DN * CKSym * DN;
if ~isreal(LapN) || any(isnan(LapN(:))) || any(isinf(LapN(:)))
    error('LapN 包含非实数、NaN 或 Inf，请检查输入矩阵！');
end
LapN = (LapN + LapN') / 2; % 强制对称，确保 Hermitian

[uN, sN, vN] = svd(LapN);
if ~isreal(vN)
    vN = real(vN); % 取实部
    warning('vN 包含虚部，已取实部！');
end
kerN = vN(:, N-n+1:N);
% 归一化，处理零向量并强制实数
kerNS = zeros(size(kerN));
for i = 1:N
    norm_val = norm(kerN(i,:) + eps);
    if norm_val > eps
        kerNS(i,:) = real(kerN(i,:) / norm_val); % 强制实数
    else
        kerNS(i,:) = real(kerN(i,:) / eps); % 避免除零
    end
end
% 确保 kerNS 为实数数组
if ~isreal(kerNS) || any(isnan(kerNS(:))) || any(isinf(kerNS(:)))
    error('kerNS 包含非实数、NaN 或 Inf，请检查 SVD 或归一化！');
end

groups = kmeans(kerNS, n, 'maxiter', MAXiter, 'replicates', REPlic, 'EmptyAction', 'singleton');
%}