function obj = calculate_obj(J_tensor, E1, E2, EH, X, Xc, W, Z_tensor, H, P, num_views, lambda1, lambda2)
    
    obj = 0;
    sum_penalty = 0;

    %% 1. J
    J_global = J_tensor(:, :, num_views+1); 
    obj = obj + norm_nuclear(J_global); 
   
    %% 2. E2^(v), EH
    for v = 1:num_views
        % E2
        E2_v_norm = 0;
        for j = 1:size(E2{v}, 2)  % 逐列
            E2_v_norm = E2_v_norm + norm(E2{v}(:, j), 2);  
        end
        obj = obj + lambda1 * E2_v_norm; 

        % EH 
        EH_norm = 0;
        for j = 1:size(EH, 2)  % 逐列
            EH_norm = EH_norm + norm(EH(:, j), 2);  
        end
        obj = obj + lambda1 * EH_norm; 
    fprintf('Norm E1{1}: %.4e, Norm E2{1}: %.4e\n', norm(E1{1}, 'fro'), norm(E2{1}, 'fro'));

    %% 3. HSIC
    hsic_value = 0;
    n = size(E1{1}, 2); 
    H_center = eye(n) - (1/n) * ones(n, n); 
    for v = 1:num_views
        % K^(v) = E1{v}' * E1{v}
        K_v = E1{v}' * E1{v};
        K_v_centered = H_center * K_v * H_center;
        for w = v+1:num_views
            % K^(w) = E1{w}' * E1{w}
            K_w = E1{w}' * E1{w};
            K_w_centered = H_center * K_w * H_center;
            % HSIC(E1{v}, E1{w}) = trace(H K^(v) H K^(w) H)
            hsic_value = hsic_value + trace(K_v_centered * K_w_centered);
        end
    end
    obj = obj + lambda2 * hsic_value / ((n-1)^2);
    fprintf('HSIC value: %.4e\n', hsic_value / ((n-1)^2));

    %% 4. ADMM 

    for v = 1:num_views
        obj = obj + 0.5 * norm(Xc{v} - P{v} * H - E1{v}, 'fro')^2; % Y1
        sum_penalty = sum_penalty + 0.5 * norm(Xc{v} - P{v} * H - E1{v}, 'fro')^2;

        obj = obj + 0.5 * norm((X{v} .* (~isnan(X{v}))) * W{v} - Xc{v} * W{v}, 'fro')^2; % Y2
        sum_penalty = sum_penalty + 0.5 * norm((X{v} .* (~isnan(X{v}))) * W{v} - Xc{v} * W{v}, 'fro')^2;

        obj = obj + 0.5 * norm(Xc{v} - Xc{v} * Z_tensor(:, :, v) - E2{v}, 'fro')^2; % Y3
        sum_penalty = sum_penalty + 0.5 * norm(Xc{v} - Xc{v} * Z_tensor(:, :, v) - E2{v}, 'fro')^2;
    end
    
    obj = obj + 0.5 * norm(H - H * Z_tensor(:, :, num_views+1) - EH, 'fro')^2; % Y4
    sum_penalty = sum_penalty + 0.5 * norm(H - H * Z_tensor(:, :, num_views+1) - EH, 'fro')^2;
    
    obj = obj + 0.5 * norm(Z_tensor(:, :, num_views+1) - J_tensor(:, :, num_views+1), 'fro')^2; % Y
    sum_penalty = sum_penalty + 0.5 * norm(Z_tensor(:, :, num_views+1) - J_tensor(:, :, num_views+1), 'fro')^2;
    
    fprintf('Obj: nuclear=%.4e, l21=%.4e, penalty=%.4e\n', norm_nuclear(J_global), lambda1*(E2_v_norm+EH_norm), sum_penalty);
end


