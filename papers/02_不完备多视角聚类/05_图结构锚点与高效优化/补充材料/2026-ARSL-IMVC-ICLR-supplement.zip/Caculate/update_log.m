function x = update_log(sigma, lambda)
deta = (1-sigma)^2-4*(lambda-sigma);
if deta<= 0
    x = 0;
else
   x = max((sigma-1+sqrt(deta))/2,0);
end