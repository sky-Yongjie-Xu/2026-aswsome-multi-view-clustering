# COPER: Correlation-based Permutations for Multi-View Clustering
## ICLR 2025 submission - in review

### How to run:

1. Download manually the dataset [Metabric](https://drive.google.com/file/d/1CiVLAnFEdqO2kaqpLpWYvAFeh0KHfbQM/view?usp=sharing)
2. Update the `cfg/metabric.yaml` with the path to the downloaded file
3. Run `main.py`




Anonymous authors